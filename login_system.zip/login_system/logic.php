<?php 
    $conn = mysqli_connect("localhost","root","","users");
    session_start();

    if(!$conn){
        echo "<h3 class='container bg-dark text-center p-3 text-warning rounded-lg mt-5'> Connection not established succesfully</h3>";
    }

    $sql = "select * from post";
    $query = mysqli_query($conn,$sql);


    if(isset($_REQUEST["submit"])){
        $title = $_REQUEST['title'];
        $content = $_REQUEST['content'];
        $sql = "INSERT INTO post(title, content) VALUES('$title','$content')";
        mysqli_query($conn,$sql);

        header("location: index.php?info=added");
        exit();
    }


    if(isset($_REQUEST["id"])){
        $id = $_REQUEST['id'];
        $sql = "select * from post where id = $id";
        $query = mysqli_query($conn,$sql);
    }

    if(isset($_REQUEST["update"])){
        $title = $_REQUEST['title'];
        $id = $_REQUEST['id'];
        $content = $_REQUEST['content'];

        $sql = "update post set title='$title' , Content ='$content' where id = $id ";
        mysqli_query($conn,$sql);
        header("location: index.php?info=updated");
        exit();
    }

    if(isset($_REQUEST["delete"])){
        $id = $_REQUEST['id'];
        $sql = "delete from post where id = $id";
        $query = mysqli_query($conn,$sql);
        header("location: index.php?info=deleted");
        exit();
    }
    if(isset($_REQUEST["logout"])){
        session_destroy();
    }
?>